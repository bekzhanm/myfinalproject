if (i % 3 === 0 || i + 1 === 1){ // zero-based index
    // open new row
}

// start new card

if (i % 3 === 0 || i === arr.length){
    // close row
}

function linkcookies() {
    window.location = "page3";
}